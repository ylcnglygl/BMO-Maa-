﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _152120141102_proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void add_Click(object sender, EventArgs e)
        {
            string dosya_yolu = @"C:\Users\guduk\OneDrive\Masaüstü\proje.txt";
            FileStream fs = new FileStream(dosya_yolu, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(textBox1.Text);
            sw.Flush();
            sw.Close();
            fs.Close();


        }

        private void update_Click(object sender, EventArgs e)
        {
          
        }

        private void okuyanbuton_Click(object sender, EventArgs e)
        {

            string dosya_yolu = @"C:\Users\guduk\OneDrive\Masaüstü\proje.txt";
            FileStream fs = new FileStream(dosya_yolu, FileMode.Open, FileAccess.Read);
            StreamReader sw = new StreamReader(fs);
            string yazi = sw.ReadLine();
            while (yazi != null)
            {
                listBox1.Items.Add(yazi);
                yazi = sw.ReadLine();
            }
            sw.Close();
            fs.Close();
        }
       
    }
}
